import { AxiosClient } from "./axiosClient";

export const getRecipesByTitle = async (title) => {
    return AxiosClient.get(`/?apikey=43d13452b52a43f482ba806da4a62b7c=${title}`)
        .then((response) => {
            return response.data.Search;
        }).catch((error) => {
            throw error;
        });
}